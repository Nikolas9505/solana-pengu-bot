import asyncio
import logging
from telegram import Bot
from telegram.ext import Application, CommandHandler
from analysis import run_analysis

TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
CHAT_ID = "YOUR_CHAT_ID"

logging.basicConfig(level=logging.INFO)

async def send_analysis(context):
    analysis = run_analysis()
    await context.bot.send_message(chat_id=CHAT_ID, text=analysis)

async def start(update, context):
    await update.message.reply_text("Бот запущено! Аналіз буде надходити кожні 15 хвилин.")

def main():
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    job_queue = application.job_queue
    job_queue.run_repeating(send_analysis, interval=900, first=10)
    application.run_polling()

if __name__ == "__main__":
    main()
