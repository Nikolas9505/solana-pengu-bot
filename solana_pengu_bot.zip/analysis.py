import random

def run_analysis():
    # Тут має бути справжній теханаліз
    signals = ["🔼 Long", "🔽 Short", "🔁 Hold"]
    return f"Solana: {random.choice(signals)}\nPENGU: {random.choice(signals)}"
